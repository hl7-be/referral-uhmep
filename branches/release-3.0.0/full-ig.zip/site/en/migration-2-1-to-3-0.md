# Migration 2.1.0 to 3.0.0 - eReferral Implementation Guide v3.0.2

* [**Table of Contents**](toc.md)
* **Migration 2.1.0 to 3.0.0**

## Migration 2.1.0 to 3.0.0

This page collects the integration checks for moving from release 2.1.0 to 3.0.0. It complements the [release notes](changes.md), the generated profiles and the operation pages. It does not replace INAMI/RIZIV business requirements.

### Release Boundaries

| | |
| :--- | :--- |
| Documented in 3.0.0 | Radiology assignment removal on the ambulatory track, completion on the urgency track, patient cancellation, explicit required profile elements and updated PSS/QSI examples. |
| Already documented in 2.1.0 | Track-dependent radiology handling, profile rewriting and pseudonymization. These are not new security mechanisms introduced by this migration. |
| Announced for a future release | Migration from the DRP IG to the Referral IG and replacement of the eReferral canonical base. Do not apply the proposed`XXX`namespace to 3.0.0 payloads. |

The checks below describe the current 3.0.0 artefacts and the changes recorded in this IG. They are not an exhaustive compatibility certification of every 2.1.0 deployment. Confirm the deployed API version, configuration and package versions in the target environment before cutover. A client upgrading from 2.1.0 should not assume that a missing field was previously valid merely because an earlier server accepted its payload.

### Payload Compatibility Checklist

| | | |
| :--- | :--- | :--- |
| Nursing prescription type | `category[prescriptionType]`is`1..1`, with one coding and a required binding to the nursing technical-type ValueSet. | Make the template coding explicit. Validate every nursing template used by the client. |
| Diagnostic-imaging prescription type | `category[prescriptionType]`is`1..1`. | Populate the prescribed imaging template rather than relying on inference. |
| Annex 81 technical type | `category[annex81TechnicalType]`is`1..1`. | Revalidate proposal and approval fixtures against the Annex 81 profile, not the generic nursing profile. |
| Nursing and diagnostic-imaging reason | `reasonCode`is`1..1`in both profiles. | Check generators that omit the reason or send multiple reasons. If the reason is patient-specific free text, retain its pseudonymization metadata. |
| Radiology track and urgency | Track is`ambulatory`,`inpatient`or`urgency`.`priority = urgent`requires an urgency justification. | Keep track and priority separate in the client model. An urgency track is not a substitute for the priority field. |
| Contained radiology resources | The diagnostic-imaging profile requires the contained patient and safety checklist, with local references. | Resolve`subject`and checklist references inside the same resource. Revalidate the contained questionnaire response. |
| Profile declaration | Use the eReferral target profile or an explicitly configured legacy DRP mapping. | Check[Profile Rewriting](topic-profile-rewriting.md), including the exact Annex 81 identifier. URL rewriting does not repair payload content. |
| Organization-scoped actor references | Follow the documented`PractitionerRole`identifier and`Task.basedOn`conventions. | Recheck requester/owner references and the organization-task link in M2M fixtures. This is a compatibility check, not a claim that the identifier convention is newly introduced in 3.0.0. |

Cardinalities and terminology bindings are defined by the generated profiles, not by this summary. Start with the [nursing profile](StructureDefinition-ereferral-servicerequest-nursing.md), [Annex 81 profile](StructureDefinition-ereferral-annex-81.md) and [diagnostic-imaging profile](StructureDefinition-ereferral-servicerequest-diagnosticimaging.md).

### Radiology Operation Matrix

This matrix focuses on migration-sensitive paths. It is not a complete authorization matrix: the [Access Matrix](operation-access-matrix.md), privacy checks, assignment ownership and operation-specific preconditions still apply. Business prescription states are not literal values for `ServiceRequest.status`. See the [status mapping](topic-prescription-lifecycle.md#business-status--fhir-status-mapping).

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| Remove assignment | Ambulatory | Authorized Caregiver for their own assignment, or Organization for its own organization task. Patient is not permitted | Prescription`READY`or`IN_PROGRESS`. Task`ready`or`in-progress` | Assignment is removed. Prescription returns to`READY`. Dependent assignments can also be affected. |
| Remove assignment | Inpatient | Any caller | Do not reuse the ambulatory exception | Radiology track guard rejects assignment removal. |
| Remove assignment | Urgency | Any caller | Do not reuse the ambulatory exception | Radiology track guard rejects assignment removal. |
| Complete an existing execution | Ambulatory | Caregiver or Organization | Prescription`IN_PROGRESS`. Caregiver task`in-progress` | Caregiver execution and radiology prescription become completed. |
| Complete an existing execution | Inpatient | Caregiver or Organization | Prescription`IN_PROGRESS`. Caregiver task`in-progress`, with applicable organization linkage | Caregiver execution and radiology prescription become completed. |
| Complete an existing execution | Urgency | Caregiver or Organization | The documented exception also permits prescription`READY`without an already-started caregiver task | The backend starts the caregiver activity when necessary, then completes it and the prescription. |
| Patient cancellation | Ambulatory | Patient | Prescription`PENDING`or`READY` | Prescription becomes canceled. |
| Patient cancellation | Inpatient | Patient | Prescription`PENDING`or`READY` | Prescription becomes canceled. |
| Patient cancellation | Urgency | Patient | Prescription`PENDING`or`READY` | Prescription becomes canceled. |

For other actors, terminal states, missing assignments and POST-based creation/completion shortcuts, use the relevant operation page rather than extrapolating from these rows. In particular, an existing-task completion and creating a task already marked `completed` are separate routes with their own preconditions.

### Organization Cancellation and Access

An Organization may cancel a caregiver execution only when the execution’s `basedOn` references an organization task assigned to that Organization. The eligible prescription state is represented by `ServiceRequest.status = active` and `BeReferralTask.status = in-progress` or `on-hold`. The request sets the execution `Task.status` to `cancelled`; it does not cancel the `ServiceRequest`. Re-read the related resources after the operation. See [Cancel Execution](operation-cancel-execution.md).

Organization access to prescription and proposal lists is separate from permission to consult an individual prescription or proposal. The backend filters list-accessible templates by the relevant list permission. Annex 81 organization policies also define prescription-level consultation/list, execution, interruption, assignment and assignment-withdrawal rights, separately from proposal rights. These permissions remain specific to the organization policy and template; they are not constraints of the Annex 81 FHIR profile.

The organization policy match uses the template, requested action and OIDC identity, not organization type. This does not replace CoBRHA identity resolution or other checks that use organization information. See [Access Matrix](operation-access-matrix.md).

### Before and After Operation Examples

These are illustrative state projections, not complete FHIR payloads or executable clinical scenarios. IDs are placeholders. Execute the documented request against a valid resource and read back the related resources to obtain the authoritative state, dates and task dependencies.

#### Ambulatory Assignment Removal

Example: an authorized caller removes an existing, in-progress ambulatory caregiver assignment.

```
DELETE /Task/{executionID}

```

| | | |
| :--- | :--- | :--- |
| Prescription business state | `IN_PROGRESS` | `READY` |
| `ServiceRequest.status` | `active` | `active` |
| `BeReferralTask.status` | `in-progress` | `ready`according to the documented business-state projection |
| Removed execution task | `status = in-progress` | Assignment deleted, not changed to`cancelled` |

The unchanged `ServiceRequest.status` does not mean that no workflow transition occurred. Refresh the referral task and assignment list. Do not use the removed assignment as an active execution identifier. [Unassign a Care Provider](operation-unassign-care-provider.md) describes the operation.

#### Urgency Completion from Ready

Example: an organization completes an existing urgency-track caregiver execution while the prescription is still `READY`. Use the PATCH payload under [Finish Existing Execution](operation-record-execution-end.md#finish-existing-execution).

| | | |
| :--- | :--- | :--- |
| Prescription business state | `READY` | `COMPLETED` |
| `ServiceRequest.status` | `active` | `completed` |
| Existing caregiver execution | Not yet started, for example task`ready` | Task`completed`. The backend starts the activity if necessary before finishing it |
| Global referral task and dates | Current server values | Read back the aggregate task and execution dates. Do not infer them solely from the submitted end date |

This exception is specific to the urgency track. It does not establish a general right to complete an ambulatory or inpatient prescription directly from `READY`, nor does it mean the client must issue a separate start request for this existing-task path.

#### Patient Cancellation

Example: the patient cancels their own radiology prescription in business state `READY` using [Cancel a Medical Document](operation-cancel-medical-document.md).

```
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "operation",
      "part": [
        { "name": "type", "valueCode": "replace" },
        { "name": "path", "valueString": "ServiceRequest.status" },
        { "name": "value", "valueString": "revoked" }
      ]
    }
  ]
}

```

| | | |
| :--- | :--- | :--- |
| Prescription business state | `READY` | Canceled |
| `ServiceRequest.status` | `active` | `revoked` |
| `BeReferralTask.status` | `ready` | `cancelled`according to the documented business-state projection |

Requery the server after the operation. Do not infer the final state of every related performer or organization task from the prescription status alone. The same documented patient-cancellation permission also covers `PENDING`. Other prescription types retain their own rules.

### Terminology and Validation Baseline

| | | |
| :--- | :--- | :--- |
| FHIR | R4,`4.0.1` | Use an R4 validator and the target profile set. |
| Local IG | `inami.fhir.be.ereferral#3.0.0` | Pin a tested build for reproducible integration tests. |
| DRP parent | `be.smals.fhir.drp-fix`, version`1.1.1`. Configured dependency`current$drp-1.1.1-fixed` | The branch alias is mutable. Record the resolved package version, build date and package checksum used for testing. |
| Belgian dependencies | Core`2.2.0`, Core Clinical`1.3.0`, INFSEC`1.3.0` | Keep validator dependencies aligned with the package under test. |
| Requested diagnostic-imaging procedure | Current profile has a required binding to the SNOMED-based local procedure ValueSet. | The presence of PSS/QSI or hybrid artefacts in the package does not itself permit PSS/QSI codes in`ServiceRequest.code`. |
| Patient-condition indication | Preferred binding plus local constraints in the diagnostic-imaging profile. | Review both the binding and applicable invariants. Do not assume the preferred binding overrides a stricter invariant. |
| SNOMED edition | Must match the coded content and the terminology service used by the target environment. | An international-edition validation failure does not alone establish that a Belgian-extension code is invalid. Confirm edition/version support before changing codes. |
| Demonstrative terminology | The homepage disclaimer distinguishes example artefacts from the future operational terminology package. | Package conformance is not evidence that every coded service is operationally supported by the API or reimbursable. |

Do not silently remove or replace clinical codes to eliminate QA errors. Confirm the intended edition, release and source mapping first. The ten [PSS radiology scenarios](artifacts.md) are illustrative inputs, not evidence that every code combination is accepted by the deployed backend.

### Regression Test Checklist

| | |
| :--- | :--- |
| Exact legacy profile mappings | Test each of the three configured DRP sources and the corresponding eReferral target. Test an unconfigured URL separately. It must not be assumed to receive the same rewrite. |
| Required elements | Validate representative nursing, Annex 81 and imaging fixtures. Include omitted template category, absent reason and excessive reason cardinality as negative profile tests. |
| Track versus priority | Cover all three tracks independently of`priority`. Test an urgent request without urgency justification. |
| Ambulatory removal | Cover the documented`READY`/`IN_PROGRESS`prescription and`ready`/`in-progress`task cases, then read back the referral task and assignments. |
| Other-track removal | Verify rejection on inpatient and urgency tracks. Capture the actual OperationOutcome and applicable error-code entry. |
| Urgency completion | Cover the existing-task path from`READY`, the normal in-progress path and valid execution dates. Test POST shortcuts separately. |
| Patient cancellation | Test an authorized patient in`PENDING`and`READY`, a different patient and a state outside those documented permissions. Confirm errors against the operation contract rather than inventing HTTP statuses. |
| Organization execution cancellation | Test the assigned Organization with an eligible`ServiceRequest`and parent`BeReferralTask`, a different Organization, and an ineligible prescription state. Confirm that only the execution`Task`is cancelled and the`ServiceRequest`is not revoked. |
| Organization list visibility | Test list access separately from individual-document access for prescription and proposal templates; verify that templates without the corresponding list permission are excluded. |
| Annex 81 organization policy | Verify prescription-level actions and proposal actions independently, including an organization identity with no matching policy. Do not infer access from the FHIR profile alone. |
| Radiology pseudonym mapping | Verify that`Patient.birthDate`content maps to the birthdate field and`be-ext-gender-at-birth`content maps to the gender-at-birth field; include distinct values to detect a swap. |
| Organization and internal professional | Exercise the organization-scoped actor reference, parent organization task and access checks. Include an incoherent`basedOn`reference. |
| Privacy | Verify pseudonymized identifiers, encrypted free text and matching key references. Never substitute real patient data into public fixtures. |
| Terminology | Test with the target edition and package versions. Distinguish invalid codes from unavailable terminology validation. |
| Retry and concurrent updates | Record behavior when an execution is already completed, an assignment was removed or the resource changes between reads. No new retry/idempotency guarantee is established by this page. |

