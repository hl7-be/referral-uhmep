# Home - eReferral Prescription Implementation Guide v1.1.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/drp | *Version*:1.1.1 |
| Active as of 2026-10-28 | *Computable Name*:eReferral Prescription |

This is the HL7 Belgium FHIR Implementation Guide for the [Referral prescription workgroup](https://wiki.hl7belgium.org/index.php?title=Procedure_Referral_Workgroup).
 General guidance is available on the [Guidance page](guidance.md) \

> **This documentation and set of artefacts are still undergoing development.**

> **This implementation guide contains only demonstrative example for terminology resources.**ValueSets and CodeSystems in this ImplementationGuide are provided as examples only. The actual ValueSets and CodeSystems will be made available from a terminology package and can then be consulted in the FHIR terminology ecosystem. 

### Content

This publication contains the specifications related to the referral prescription areas and is structured in the following content sections:

**Background:**
 Information about the HL7 Belgium specifications, or what you should know to be able to best navigate and use these specifications. Contains a general introduction to the publication structure and content, the artefact types, common privacy and security specifications and the official HL7 FHIR release that this specification is based upon.

**Functional Description:**
 Functional content, more relevant for business or functional analysts, as well as health professionals. Contains the context around these specifications (relevant projects, legal and implementation aspects), the interoperability actors and transactions, and especially the use cases that have been considered in the specification and the logical data models - the functional (i.e. non-technical) data sets that are used in data exchange.

**Detailed Specifications:**
 The actual technical specifications - the FHIR conformance resources that are defined in this specification - profiles, data types, capability statements. This is targeted at (technical) implementers.

**Terminology:**
 The vocabulary resources - Code Systems and value sets, that support semantic interoperability. These resources promote the use of standard, controlled terminologies (e.g. SNOMED-CT) and define internal codes for Belgium, e.g. official codes for Civil Status).

**Implementation:**
 Content, Tools and resources to help in implementation - test data (example resources), currently available test servers, and other tools to validate the compatibility between systems and these specifications.

There is also an overview of the projects and motivation for the specifications.

-------

### Navigation

This implementation guide uses the FHIR web-based publication. This allows easy navigation between the Belgium-specific portion of the implementation guide and the resources, data types, value sets and other specification components leveraged from the FHIR core specification. This approach also allows implementers to easily navigate to the information needed to perform a task.

The top menu allows quick navigation to the different sections, and a [Table of Contents](toc.md) is provided with the entire content of this Implementation Guide. (Be aware that some pages have multiple tabs).

-------

### Intellectual Property Considerations

While this implementation guide and the underlying FHIR are licensed as public domain, this guide includes examples making use of terminologies such as LOINC, SNOMED CT and others which have more restrictive licensing requirements. Implementers should make themselves familiar with licensing and any other constraints of terminologies, questionnaires, and other components used as part of their implementation process. In some cases, licensing requirements may limit the systems that data captured using certain questionnaires may be shared with.

-------

### Disclaimer

The specification herewith documented is a first working specification. Implementers are requested to provide feedback on its implementation.



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "be.smals.fhir.drp-fix",
  "url" : "https://www.ehealth.fgov.be/standards/fhir/drp",
  "version" : "1.1.1",
  "name" : "eReferral Prescription",
  "title" : "eReferral Prescription Implementation Guide",
  "status" : "active",
  "date" : "2026-10-28",
  "publisher" : "eHealth Platform",
  "contact" : [{
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ehealth.fgov.be/standards/fhir"
    },
    {
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net"
    }]
  },
  {
    "name" : "Message Structure eHealth",
    "telecom" : [{
      "system" : "email",
      "value" : "support@be-ehealth-standards.atlassian.net",
      "use" : "work"
    }]
  }],
  "description" : "Corrected Digital Referral Prescription parent profiles for eReferral 3.0.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "packageId" : "be.smals.fhir.drp-fix",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.5.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.4.0"
  },
  {
    "id" : "hl7_fhir_be_core",
    "uri" : "https://www.ehealth.fgov.be/standards/fhir/core/ImplementationGuide/hl7.fhir.be.core",
    "packageId" : "hl7.fhir.be.core",
    "version" : "2.2.0"
  },
  {
    "id" : "hl7_fhir_be_core_clinical",
    "uri" : "https://www.ehealth.fgov.be/standards/fhir/core-clinical/ImplementationGuide/hl7.fhir.be.core-clinical",
    "packageId" : "hl7.fhir.be.core-clinical",
    "version" : "1.3.0"
  },
  {
    "id" : "hl7_fhir_uv_xver_r5_r4",
    "uri" : "http://hl7.org/fhir/uv/xver/ImplementationGuide/hl7.fhir.uv.xver-r5.r4",
    "packageId" : "hl7.fhir.uv.xver-r5.r4",
    "version" : "0.1.0"
  },
  {
    "id" : "hl7_fhir_be_infsec",
    "uri" : "https://www.ehealth.fgov.be/standards/fhir/infsec/ImplementationGuide/hl7.fhir.be.infsec",
    "packageId" : "hl7.fhir.be.infsec",
    "version" : "1.3.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/expansion-parameters",
      "valueReference" : {
        "reference" : "Parameters/expansion-parameters"
      }
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.3.0"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2022+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "STU"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "Parameters-terminology-expansion.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-multiples"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://www.ehealth.fgov.be/standards/fhir/drp/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "special-url-base"
      },
      {
        "url" : "value",
        "valueString" : "https://www.ehealth.fgov.be/standards/fhir/terminology"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-annex-81.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-annex-81"
      },
      "name" : "BeAnnex81",
      "description" : "Annex81 proposal and approval",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-feedback-to-prescriber.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-feedback-to-prescriber"
      },
      "name" : "BeFeedbackToPrescriber",
      "description" : "Whether the prescriber requests feedback on the processing of the order",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "GraphDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "GraphDefinition-full-referral-prescription.html"
      }],
      "reference" : {
        "reference" : "GraphDefinition/full-referral-prescription"
      },
      "name" : "BeGDFullReferralPrescription",
      "description" : "Specify to include all useful resources around a ServiceRequest that can be retrieved with the $graph operation.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-imaging-attention-conditions-response.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-imaging-attention-conditions-response"
      },
      "name" : "BeImagingAttentionConditionsResponse",
      "description" : "Response to the imaging attention conditions questionnaire. At least one attention condition must be answered.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-latest-end-date.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-latest-end-date"
      },
      "name" : "BeLatestEndDate",
      "description" : "Request must be performed before",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BeModelAnnex81.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BeModelAnnex81"
      },
      "name" : "BeModelAnnex81",
      "description" : "Logical model describing the model for the Annex81 proposal and approval",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BeModelAssignment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BeModelAssignment"
      },
      "name" : "BeModelAssignment",
      "description" : "Logical model with the information for the assignment to a referral prescription of a care provider.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BeModelNursingPrescription.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BeModelNursingPrescription"
      },
      "name" : "BeModelNursingPrescription",
      "description" : "Data model for the nursing prescription referral.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BeModelOrganisationClaim.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BeModelOrganisationClaim"
      },
      "name" : "BeModelOrganisationClaim",
      "description" : "Information of a claim of an organisation to have the prescription fulfilled.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BeModelReferralPrescription.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BeModelReferralPrescription"
      },
      "name" : "BeModelReferralPrescription",
      "description" : "Data model for the prescription referral.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-BeModelTreatmentStatus.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BeModelTreatmentStatus"
      },
      "name" : "BeModelTreatmentStatus",
      "description" : "Logical model with the information for the status of the treatment.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "NamingSystem-be-ns-uhmep-short.html"
      }],
      "reference" : {
        "reference" : "NamingSystem/be-ns-uhmep-short"
      },
      "name" : "BeNsUhmepShort",
      "description" : "Naming system identifier for the UHMEP user friendly short code",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-be-op-approve-annex81.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/be-op-approve-annex81"
      },
      "name" : "BeOpApproveAnnex81",
      "description" : "Creates an approval from an Annex81 proposal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "OperationDefinition"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "OperationDefinition-be-op-reject-annex81.html"
      }],
      "reference" : {
        "reference" : "OperationDefinition/be-op-reject-annex81"
      },
      "name" : "BeOpRejectAnnex81",
      "description" : "Rejects an Annex81 proposal",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-organization-task.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-organization-task"
      },
      "name" : "BeOrganizationTask",
      "description" : "Subtask to assign the referral task and prescription to one or more members of this organisation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-performer-task.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-performer-task"
      },
      "name" : "BePerformerTask",
      "description" : "Subtask performed by one performer",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-performer-type.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-performer-type"
      },
      "name" : "BePerformerType",
      "description" : "Types of performers that can execute this request",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-prescription-status-reason.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-prescription-status-reason"
      },
      "name" : "BePrescriptionStatusReason",
      "description" : "DEMONSTRATIVE EXAMPLE - Status reason for the prescription. Initially defined as supporting CodeSystem for the referral prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "NamingSystem-be-ns-pss-id.html"
      }],
      "reference" : {
        "reference" : "NamingSystem/be-ns-pss-id"
      },
      "name" : "BePSSId",
      "description" : "PSS ID naming system",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-pss-info.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-pss-info"
      },
      "name" : "BePSSInfo",
      "description" : "Information regarding the Prescription Search Support",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-referral-servicerequest.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-referral-servicerequest"
      },
      "name" : "BeReferralServiceRequest",
      "description" : "The common structure for referral prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-referral-servicerequest-nursing.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-referral-servicerequest-nursing"
      },
      "name" : "BeReferralServiceRequestNursing",
      "description" : "The nursing profile, generic version. Please note the nursing referral for medication does NOT depend on this generic version but is a FHIR prodfile on a different FHIR resource (MedicationRequest)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-referral-task.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-referral-task"
      },
      "name" : "BeReferralTask",
      "description" : "The task that is referred to in the referral prescription (this is the common task for the execution of the prescription). The subtasks per performer can be found in BePerformerTask",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-relevant-info.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-relevant-info"
      },
      "name" : "BeRelevantInfo",
      "description" : "Relevant clinical information in the context of this prescription concerning for example allergies, kidney function, diabetic. This extension allows the use of an Annotation or codeableConcept but when more detailed information can be given, it is RECOMMENDED to express it as structured as possible using the appropriate elements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-referral-servicerequest-diagnosticimaging.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-referral-servicerequest-diagnosticimaging"
      },
      "name" : "BeServiceRequestDiagnosticImaging",
      "description" : "The diagnostic imaging profile. Generic version.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-treatment-status-reason.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-treatment-status-reason"
      },
      "name" : "BeTreatmentStatusReason",
      "description" : "DEMONSTRATIVE EXAMPLE - Status reason for the treatment. Initially defined as supporting CodeSystem for the referral prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "NamingSystem-be-ns-uhmep.html"
      }],
      "reference" : {
        "reference" : "NamingSystem/be-ns-uhmep"
      },
      "name" : "BeUnadressedHealthMessageExchangePlatform",
      "description" : "UHMEP naming system",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-urgency-justification.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-urgency-justification"
      },
      "name" : "BeUrgencyJustification",
      "description" : "Justification for the urgency level assigned to the request",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-validity-period.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-validity-period"
      },
      "name" : "BeValidityPeriod",
      "description" : "Begin and end date of the validity of the request",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-annex81-status-reason.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-annex81-status-reason"
      },
      "name" : "BeVSAnnex81StatusReason",
      "description" : "DEMONSTRATIVE EXAMPLE - Status reason of the Annex 81",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-prescription-status-reason.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-prescription-status-reason"
      },
      "name" : "BeVSPrescriptionStatusReason",
      "description" : "eReferral reasons for the status of the prescription",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-request-intent.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-request-intent"
      },
      "name" : "BeVSRequestIntent",
      "description" : "eReferral allowed intent codes in the context of referral prescription",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-task-intent.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-task-intent"
      },
      "name" : "BeVSTaskIntent",
      "description" : "DEMONSTRATIVE EXAMPLE - The allowed intent codes in the context of tasks in the field of referral prescriptions",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-treatment-status-reason.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-treatment-status-reason"
      },
      "name" : "BeVSTreatmentStatusReason",
      "description" : "DEMONSTRATIVE EXAMPLE - Codes for the current status of a treatment in a referral prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-codeable-concept.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-codeable-concept"
      },
      "name" : "CodeableConcept Extension for Reference",
      "description" : "Extension able to hold a coded concept on a Reference element.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-annex81-care-requested.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-annex81-care-requested"
      },
      "name" : "eReferral Annex 81 Care Requested",
      "description" : "Clinical care services for Annex 81 prescriptions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-annex81-medical-problem.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-annex81-medical-problem"
      },
      "name" : "eReferral Annex 81 Medical Problem",
      "description" : "Medical problems/conditions that can justify an Annex 81 request.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-annex81-nursing-diagnosis.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-annex81-nursing-diagnosis"
      },
      "name" : "eReferral Annex 81 Nursing Diagnosis",
      "description" : "Nursing diagnoses/findings that can motivate an Annex 81 request.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-annex81-status-reason.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-annex81-status-reason"
      },
      "name" : "eReferral Annex 81 Status Reason",
      "description" : "DEMONSTRATIVE EXAMPLE - Status reason for the Annex 81",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-annex81-technical-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-annex81-technical-type"
      },
      "name" : "eReferral Annex 81 Technical Type",
      "description" : "Technical type for Annex 81 prescriptions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-body-site.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-body-site"
      },
      "name" : "eReferral Body Site",
      "description" : "Anatomical body sites based on SNOMED CT for use in referral prescriptions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-body-topography.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-body-topography"
      },
      "name" : "eReferral Body Topography",
      "description" : "Topographical qualifiers for body sites based on SNOMED CT.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-categories-of-care.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-categories-of-care"
      },
      "name" : "eReferral Categories of Care",
      "description" : "Categories of care that can be prescribed by a GP in the eReferral project. Currently limited to nursing care.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-diabetes-education-identifier.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-diabetes-education-identifier"
      },
      "name" : "eReferral Diabetes Education Identifier",
      "description" : "Identifiers to distinguish types of diabetes education prescriptions.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-diabetic-education-type.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-diabetic-education-type"
      },
      "name" : "eReferral Diabetic Education Type",
      "description" : "Types of diabetes education activities.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-education-type-with-trajectory.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-education-type-with-trajectory"
      },
      "name" : "eReferral Education Type With Trajectory",
      "description" : "Types of diabetes education for education within a care trajectory.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-education-type-without-trajectory.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-education-type-without-trajectory"
      },
      "name" : "eReferral Education Type Without Trajectory",
      "description" : "Types of diabetes education for patients without a trajectory.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-educator-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-educator-type"
      },
      "name" : "eReferral Educator Type",
      "description" : "Types of educators for diabetes education activities.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-generic-care-types.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-generic-care-types"
      },
      "name" : "eReferral Generic Care Types",
      "description" : "Types of care that can be prescribed via the generic prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-glycemia-measurement-time.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-glycemia-measurement-time"
      },
      "name" : "eReferral Glycemia Measurement Time",
      "description" : "Timing of glycemia measurements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-glycemia-measurement-timing.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-glycemia-measurement-timing"
      },
      "name" : "eReferral Glycemia Measurement Timing",
      "description" : "Timing of glycemia measurements.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-imaging-modality.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-imaging-modality"
      },
      "name" : "eReferral Imaging Modality",
      "description" : "Imaging modality types for prior imaging requests",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-imaging-modality.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-imaging-modality"
      },
      "name" : "eReferral Imaging Modality ValueSet",
      "description" : "Allowed modalities for imaging requests.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-imaging-priority.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-imaging-priority"
      },
      "name" : "eReferral Imaging Priority",
      "description" : "Priority codes for diagnostic imaging requests",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-imaging-priority.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-imaging-priority"
      },
      "name" : "eReferral Imaging Priority ValueSet",
      "description" : "Allowed priorities for imaging requests.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-implant-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-implant-type"
      },
      "name" : "eReferral Implant Type",
      "description" : "Allowed implant types.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-note-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-note-type"
      },
      "name" : "eReferral Note Type",
      "description" : "Types of notes that can be associated with a referral prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-note-types.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-note-types"
      },
      "name" : "eReferral Note Types",
      "description" : "Types of notes that can be associated with a prescription.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-nursing-care-requested.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-nursing-care-requested"
      },
      "name" : "eReferral Nursing Care Requested",
      "description" : "Clinical care services that can be prescribed for nursing care using SNOMED CT.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-nursing-prescription-technical-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-nursing-prescription-technical-type"
      },
      "name" : "eReferral Nursing Prescription Technical Type",
      "description" : "Technical types of nursing prescriptions for routing and workflow purposes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-parameter-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-parameter-type"
      },
      "name" : "eReferral Parameter Type",
      "description" : "Types of parameters/vital signs that can be measured.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-prescription-type.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-prescription-type"
      },
      "name" : "eReferral Prescription Type",
      "description" : "Technical types of prescriptions supported by the eReferral system. Used for routing and workflow purposes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-prescription-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-prescription-type"
      },
      "name" : "eReferral Prescription Type ValueSet",
      "description" : "Technical types of prescriptions supported by the eReferral system. Used for routing and workflow purposes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-radiology-supporting-info-role.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-radiology-supporting-info-role"
      },
      "name" : "eReferral Radiology SupportingInfo Role",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-radiology-supporting-info-role.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-radiology-supporting-info-role"
      },
      "name" : "eReferral Radiology SupportingInfo Role CodeSystem",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-radiology-supporting-info-role.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-radiology-supporting-info-role"
      },
      "name" : "eReferral Radiology SupportingInfo Role ValueSet",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-request-track.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-request-track"
      },
      "name" : "eReferral request track",
      "description" : "Allowed request tracks. Extends the official Belgian request track value set with UHMEP-specific codes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-request-track.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-request-track"
      },
      "name" : "eReferral Request Track",
      "description" : "Care setting track codes for diagnostic imaging requests",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-sample-substance-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-sample-substance-type"
      },
      "name" : "eReferral Sample Substance Type",
      "description" : "Types of samples/substances that can be collected.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-session-type.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-session-type"
      },
      "name" : "eReferral Session Type",
      "description" : "Types of sessions for education or care activities (standard).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-session-type-extended.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-session-type-extended"
      },
      "name" : "eReferral Session Type Extended",
      "description" : "Types of sessions for education or care activities (extended, including combination).",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-session-types.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-session-types"
      },
      "name" : "eReferral Session Types",
      "description" : "Types of sessions for education or care activities.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:extension"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-be-ext-string-date.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/be-ext-string-date"
      },
      "name" : "eReferral String Date",
      "description" : "Date represented as a string. This extension is used to capture date information in a string format when a date must be encrypted.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-diagnostic-imaging-indication.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-diagnostic-imaging-indication"
      },
      "name" : "eReferral/PSS Diagnostic Imaging Indication",
      "description" : "Clinical indications and findings that can support a diagnostic imaging request using SNOMED CT.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-diagnostic-imaging-procedure.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-diagnostic-imaging-procedure"
      },
      "name" : "eReferral/PSS Diagnostic Imaging Procedure",
      "description" : "Diagnostic care services that can be prescribed for diagnostic imaging using SNOMED CT.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Questionnaire"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Questionnaire-be-questionnaire-imaging-attention-conditions.html"
      }],
      "reference" : {
        "reference" : "Questionnaire/be-questionnaire-imaging-attention-conditions"
      },
      "name" : "Imaging Attention Conditions Questionnaire",
      "description" : "Questionnaire for capturing attention-worthy conditions relevant to diagnostic imaging requests (implants, pregnancy, diabetes, allergies, etc.)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ValueSet-be-vs-pss-indication.html"
      }],
      "reference" : {
        "reference" : "ValueSet/be-vs-pss-indication"
      },
      "name" : "PSS Indication",
      "description" : "Indication codes for diagnostic imaging requests as PSS Internal Codes.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "CodeSystem-be-cs-pss-indication.html"
      }],
      "reference" : {
        "reference" : "CodeSystem/be-cs-pss-indication"
      },
      "name" : "PSS Indication ValueSet",
      "description" : "PSS indication codes for diagnostic imaging requests.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "Parameters-terminology-expansion.html"
      }],
      "reference" : {
        "reference" : "Parameters/terminology-expansion"
      },
      "name" : "terminology-expansion",
      "exampleBoolean" : false
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Home",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "guidance.html"
        }],
        "nameUrl" : "guidance.html",
        "title" : "Guidance",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "changes.html"
        }],
        "nameUrl" : "changes.html",
        "title" : "Changes",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "downloads.html"
        }],
        "nameUrl" : "downloads.html",
        "title" : "Downloads",
        "generation" : "html"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
